import React, { useState } from 'react'
import {
  ArrowLeft, ArrowRight, Bell, CalendarDays, Camera, Check, ChevronRight,
  Clock3, Home, Image, Info, Lock, Mail, MapPin, Menu, MessageSquare,
  MoreHorizontal, Pencil, Phone, Plus, Search, Settings, ShieldCheck,
  Ticket, User, Users, X
} from 'lucide-react'
import { Link, Navigate, Route, Routes, useLocation, useNavigate, useParams } from 'react-router-dom'

const purple = '#35107f'

const events = [
  { id:'youth-conference-2024', title:'Youth Conference 2024', date:'Sat, 25 May 2024', time:'10:00 AM', location:'Global Impact Church, Lekki', image:'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=900&q=80', tag:'Youth' },
  { id:'prayer-meeting', title:'Prayer Meeting', date:'Wed, 29 May 2024', time:'6:00 PM', location:'Online', image:'https://images.unsplash.com/photo-1507692049790-de58290a4334?auto=format&fit=crop&w=900&q=80', tag:'General' },
  { id:'women-of-impact', title:'Women of Impact', date:'Sat, 1 Jun 2024', time:'10:00 AM', location:'Global Impact Church', image:'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?auto=format&fit=crop&w=900&q=80', tag:'Women' },
  { id:'leadership-seminar', title:'Leadership Seminar', date:'Sat, 8 Jun 2024', time:'10:00 AM', location:'Global Impact Church', image:'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?auto=format&fit=crop&w=900&q=80', tag:'Leadership' },
]

const ministries = [
  { id:'youth', title:'Youth Ministry', desc:'Equipping and raising young leaders.', image:'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=700&q=80' },
  { id:'ushering', title:'Ushering Ministry', desc:'Serving with excellence and a heart.', image:'https://images.unsplash.com/photo-1516321497487-e288fb19713f?auto=format&fit=crop&w=700&q=80' },
  { id:'media', title:'Media Ministry', desc:"Telling the story of God's work.", image:'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=700&q=80' },
]

function Logo({ light=false }) {
  return <div className={`logo ${light ? 'light' : ''}`}><b>GiC</b><span>GLOBAL IMPACT CHURCH</span></div>
}

function Button({ children, variant='primary', className='', ...props }) {
  return <button className={`btn ${variant} ${className}`} {...props}>{children}</button>
}

function Field({ label, value, type='text', placeholder, icon: Icon }) {
  return <label className="field">
    <span>{label}</span>
    <div className="field-wrap">{Icon && <Icon size={15}/>}<input type={type} defaultValue={value} placeholder={placeholder}/></div>
  </label>
}

function SelectField({ label, value, children }) {
  return <label className="field">
    <span>{label}</span>
    <select defaultValue={value}><option>{value}</option>{children}</select>
  </label>
}

function Back({ to='/' }) {
  return <Link className="back" to={to}><ArrowLeft size={18}/></Link>
}

function BottomNav({ active='home' }) {
  const items = [
    ['home','Home',Home,'/home'],
    ['events','Events',CalendarDays,'/events'],
    ['ministries','Ministries',Users,'/ministries'],
    ['notifications','Notifications',Bell,'/notifications'],
    ['profile','Profile',User,'/profile'],
  ]
  return <nav className="bottom-nav">{items.map(([id,label,Icon,to]) =>
    <Link key={id} className={active===id?'active':''} to={to}><Icon size={18}/><small>{label}</small></Link>
  )}</nav>
}

function MemberShell({ children, active='home', title, backTo }) {
  return <div className="member-page">
    <header className="mobile-header">
      {backTo ? <Back to={backTo}/> : <Menu size={20}/>}
      {title ? <strong>{title}</strong> : <Logo/>}
      <Bell size={18}/>
    </header>
    <main className="mobile-main">{children}</main>
    <BottomNav active={active}/>
  </div>
}

function OnboardingShell({ children, step, title }) {
  return <div className="onboarding-page">
    <div className="onboarding-card">
      <div className="onboard-top"><Back to={step===1?'/':-1}/><span>{step} / 7</span></div>
      <div className="onboard-title">{title}</div>
      {children}
    </div>
  </div>
}

function Welcome() {
  return <div className="welcome-page">
    <div className="welcome-overlay">
      <Logo light/>
      <div className="welcome-copy">
        <p>Welcome to</p><h1>Global Impact Church</h1>
        <p>A place where destinies are transformed and dreams take their rightful place.</p>
      </div>
      <div>
        <Link className="btn gold wide" to="/onboarding/create-account">Create Account</Link>
        <Link className="text-link" to="/signin">I already have an account</Link>
      </div>
    </div>
  </div>
}

function CreateAccount() {
  return <OnboardingShell step={2} title="Create Account">
    <p className="sub">Let's get you started</p>
    <div className="stack">
      <Field label="First Name" value="John"/>
      <Field label="Last Name" value="Doe"/>
      <Field label="Phone Number" value="+234 801 234 5678"/>
      <Field label="Email Address" value="john.doe@gmail.com"/>
      <Field label="Password" value="••••••••••" type="password"/>
      <label className="check"><input type="checkbox" defaultChecked/> I agree to the <u>Terms & Conditions</u></label>
      <Link className="btn primary wide" to="/onboarding/verify">Create Account</Link>
      <div className="tiny">Already have an account? <Link to="/signin">Sign in</Link></div>
    </div>
  </OnboardingShell>
}

function Verify() {
  const nav = useNavigate()
  const [code,setCode] = useState(['1','2','3','4','5','6'])
  return <OnboardingShell step={3} title="Verify Your Account">
    <p className="sub">Enter the 6-digit code sent to<br/><b>+234 801 234 5678</b></p>
    <div className="otp">{code.map((x,i)=><input key={i} maxLength="1" value={x} onChange={e=>{const n=[...code];n[i]=e.target.value;nav;setCode(n)}}/>)}</div>
    <div className="center muted">Resend code in 00:45</div>
    <button className="link-button">Resend Code</button>
    <Link className="link-button" to="/onboarding/profile">Use Email Instead</Link>
  </OnboardingShell>
}

function CompleteProfile() {
  return <OnboardingShell step={4} title="Complete Your Profile">
    <p className="sub">Tell us a bit more about yourself</p>
    <div className="avatar large"><span>JD</span><button><Camera size={13}/></button></div>
    <div className="stack">
      <Field label="Date of Birth" value="12 March 1995"/>
      <SelectField label="Location" value="Lagos, Nigeria"><option>Abuja, Nigeria</option></SelectField>
      <SelectField label="Preferred Service" value="9:00 AM Service"><option>11:00 AM Service</option></SelectField>
      <Link className="btn primary wide" to="/onboarding/ministries">Continue</Link>
    </div>
  </OnboardingShell>
}

function SelectMinistries() {
  const [selected,setSelected] = useState(['Youth','Ushering'])
  const names=['Youth','Choir','Children','Ushering','Media','Evangelism','Protocol','Small Groups']
  return <OnboardingShell step={5} title="Select Ministries">
    <p className="sub">Choose the ministries you're part of or interested in</p>
    <div className="choice-grid">{names.map(n=><button key={n} className={selected.includes(n)?'selected':''} onClick={()=>setSelected(s=>s.includes(n)?s.filter(x=>x!==n):[...s,n])}><span>{n[0]}</span>{n}<Check size={14}/></button>)}</div>
    <input className="other-input" placeholder="Other (specify)"/>
    <Link className="btn primary wide" to="/onboarding/notifications">Continue</Link>
  </OnboardingShell>
}

function NotificationPreferences() {
  const [prefs,setPrefs]=useState({a:true,b:true,c:true,d:true,e:true})
  return <OnboardingShell step={6} title="Notification Preferences">
    <p className="sub">Choose what you'd like to receive</p>
    <div className="preference-list">{[
      ['a','General Announcements','Stay updated with important church news'],
      ['b','Events & Programs','Updates about events and programs'],
      ['c','Ministry Updates','News from your ministries'],
      ['d','Reminders','Service & event reminders'],
      ['e','Important Notices','Urgent or important information'],
    ].map(([id,a,b])=><div className="pref" key={id}><div><b>{a}</b><small>{b}</small></div><button className={`switch ${prefs[id]?'on':''}`} onClick={()=>setPrefs({...prefs,[id]:!prefs[id]})}><i/></button></div>)}</div>
    <Link className="btn primary wide" to="/onboarding/complete">Continue</Link>
  </OnboardingShell>
}

function OnboardingComplete() {
  return <div className="success-page"><div className="success-card"><Logo light/><div className="success-icon"><Check size={34}/></div><h1>You're All Set!</h1><p>Welcome to Global Impact Church Family.</p><p>You can now explore the app and stay connected.</p><Link className="btn gold wide" to="/home">Go to Dashboard</Link></div></div>
}

function HomePage() {
  return <MemberShell active="home">
    <section className="hero-card">
      <div className="hero-brand"><Logo light/></div>
      <div><small>Good Morning,</small><h2>John 👋</h2><p>Here's what's happening in Global Impact Church</p></div>
    </section>
    <section className="section"><div className="section-head"><span>Latest Announcement</span></div><article className="announcement-card"><div className="image-banner" style={{backgroundImage:`url(${events[0].image})`}}/><div className="pad"><small>Sunday Service Update</small><h3>Join us this Sunday for a powerful time in God's presence.</h3><Link to="/announcements/1">View Details</Link></div></article></section>
    <section className="section"><div className="section-head"><span>Upcoming Events</span><Link to="/events">View All</Link></div>{events.slice(0,2).map(e=><EventRow key={e.id} event={e}/>)}</section>
  </MemberShell>
}

function EventRow({event}) {
  return <Link className="event-row" to={`/events/${event.id}`}><img src={event.image}/><div><b>{event.title}</b><small>{event.date} • {event.time}</small><small>{event.location}</small></div><ChevronRight size={16}/></Link>
}

function Announcements() {
  return <MemberShell active="home" title="Announcements" backTo="/home">
    <div className="tabs"><button className="active">All</button><button>General</button><button>Ministries</button><button>Notices</button></div>
    {[['Sunday Service Update',events[0].image,'Join us this Sunday for a powerful time in God’s presence.'],['Building Project Update',events[1].image,'Thank you for your continued support and prayers.'],['Midweek Service',events[2].image,'Our Midweek Service holds this Wednesday.'],['New Members Class',events[3].image,'If you are new here, join our New Members Class.']].map((x,i)=><article className="list-card" key={i}><img src={x[1]}/><div><b>{x[0]}</b><small>{x[2]}</small><time>May {10+i}, 2024</time></div></article>)}
  </MemberShell>
}

function EventsPage() {
  return <MemberShell active="events" title="Events" backTo="/home">
    <div className="segmented"><button className="active">Upcoming</button><Link to="/my-registrations">My Registrations</Link></div>
    {events.map(e=><EventRow key={e.id} event={e}/>)}
  </MemberShell>
}

function EventDetails() {
  const {id}=useParams(); const e=events.find(x=>x.id===id)||events[0]
  return <MemberShell active="events" backTo="/events" title=""><div className="detail-image" style={{backgroundImage:`url(${e.image})`}}/><div className="detail-body"><h1>{e.title}</h1><div className="detail-meta"><span><CalendarDays size={15}/>{e.date}</span><span><Clock3 size={15}/>{e.time}</span><span><MapPin size={15}/>{e.location}</span><span><Ticket size={15}/>Free</span></div><p>An exciting time of worship, word, workshops and encounters. Don't miss it!</p><h3>What to Expect</h3><ul className="check-list"><li>Powerful Worship</li><li>Inspiring Sessions</li><li>Networking</li><li>And more</li></ul><Link className="btn primary wide" to={`/events/${e.id}/register`}>Register Now</Link></div></MemberShell>
}

function EventRegistration() {
  return <MemberShell active="events" title="Register for Event" backTo="/events"><div className="form-title"><h2>Youth Conference 2024</h2></div><div className="stack"><Field label="Full Name" value="John Doe"/><Field label="Email Address" value="john.doe@gmail.com"/><Field label="Phone Number" value="+234 801 234 5678"/><SelectField label="Ministry (Optional)" value="Youth"><option>Choir</option></SelectField><SelectField label="Dietary Preference (Optional)" value="None"><option>Vegetarian</option></SelectField><label className="check"><input type="checkbox" defaultChecked/> I agree to the event <u>terms and conditions</u></label><Link className="btn primary wide" to="/events/youth-conference-2024/success">Submit Registration</Link></div></MemberShell>
}

function RegistrationSuccess() {
  return <div className="success-page"><div className="success-card"><div className="success-icon green"><Check size={34}/></div><h1>You're Registered!</h1><p>You have successfully registered for<br/><b>Youth Conference 2024</b></p><button className="btn white wide"><CalendarDays size={16}/> Add to Calendar</button><Link className="btn outline wide" to="/events">Back to Events</Link></div></div>
}

function FormsPage() {
  const forms=[['Prayer Request Form','Submit your prayer requests. We are here to pray with you.', '🙏'],['Visitor Registration','Are you visiting for the first time? We’d love to connect with you.','👋'],['Volunteer Application','Join a team and serve in the house.','🙌'],['Tithe & Offering Form','Submit your tithe or offering details here.','💚']]
  return <MemberShell active="home" title="Forms" backTo="/home"><div className="segmented"><button className="active">All Forms</button><button>My Submissions</button></div>{forms.map((f,i)=><Link className="form-card" to={i===0?'/forms/prayer-request':'#'} key={f[0]}><span>{f[2]}</span><div><b>{f[0]}</b><small>{f[1]}</small></div><ChevronRight size={16}/></Link>)}</MemberShell>
}

function PrayerRequest() {
  return <MemberShell active="home" title="Prayer Request Form" backTo="/forms"><p className="center muted">We believe in the power of prayer.<br/>Please share your request with us.</p><div className="stack"><Field label="Your Name" value="John Doe"/><Field label="Phone Number" value="+234 801 234 5678"/><label className="field"><span>Your Prayer Request</span><textarea defaultValue="Please pray for my family and for divine direction."/></label><SelectField label="Would you like someone to contact you?" value="Yes"><option>No</option></SelectField><Button className="wide">Submit Prayer Request</Button></div></MemberShell>
}

function MinistriesPage() {
  return <MemberShell active="ministries" title="My Ministries" backTo="/home"><p className="muted">Ministries you are part of</p>{ministries.map(m=><Link className="ministry-row" key={m.id} to={`/ministries/${m.id}`}><img src={m.image}/><div><b>{m.title}</b><small>{m.desc}</small></div><ChevronRight size={16}/></Link>)}</MemberShell>
}

function MinistryDetails() {
  return <MemberShell active="ministries" backTo="/ministries"><div className="ministry-cover" style={{backgroundImage:`url(${ministries[0].image})`}}><h1>YOUTH<br/>MINISTRY</h1></div><div className="detail-body"><h2>Youth Ministry</h2><p>Equipping and raising young leaders for impact.</p><div className="mini-tabs"><button className="active">About</button><button>Updates</button></div><div className="upcoming-box"><b>Upcoming Meeting</b><span>Friday, 24 May 2024 • 6:00 PM</span><span>Youth Hall</span></div><div className="contact"><div className="avatar">JS</div><div><small>Contact Leader</small><b>John Smith</b><span>+234 801 111 2222</span></div></div></div></MemberShell>
}

function Notifications() {
  const items=[['New Announcement','Sunday Service Update','2m ago','green'],['Event Reminder','Youth Conference 2024','1h ago','red'],['Ministry Update','Youth Ministry Update','3h ago','purple'],['New Form Available','Volunteer Application','1d ago','blue'],['Important Notice','Midweek Service Update','2d ago','red']]
  return <MemberShell active="notifications" title="Notifications" backTo="/home">{items.map((x,i)=><Link className="notification-row" key={i} to={i===0?'/notifications/1':'#'}><span className={`notif-icon ${x[3]}`}><Bell size={14}/></span><div><b>{x[0]}</b><small>{x[1]}</small></div><time>{x[2]}</time></Link>)}</MemberShell>
}

function NotificationDetail() {
  return <MemberShell active="notifications" title="Sunday Service Update" backTo="/notifications"><time className="date-line">May 19, 2024 • 9:00 AM</time><div className="detail-image" style={{backgroundImage:`url(${events[0].image})`}}/><div className="detail-body"><p>Join us this Sunday for a powerful time in God's presence.</p><p>We look forward to worshiping and growing together.</p><Link className="btn primary wide" to="/announcements/1">View Full Announcement</Link></div></MemberShell>
}

function Profile() {
  return <MemberShell active="profile" title="My Profile" backTo="/home"><div className="profile-head"><div className="avatar large">JD</div><h2>John Doe</h2><span>Member</span></div><div className="profile-menu">{[['Personal Information',Pencil,'/profile/edit'],['Ministries',Users,'/ministries'],['Notification Preferences',Bell,'/onboarding/notifications'],['Change Password',Lock,'#'],['App Settings',Settings,'#'],['Log Out',ArrowRight,'/']].map(([x,I,to])=><Link to={to} key={x}><I size={17}/><span>{x}</span><ChevronRight size={15}/></Link>)}</div></MemberShell>
}

function EditProfile() {
  return <MemberShell active="profile" title="Edit Profile" backTo="/profile"><div className="profile-head"><div className="avatar large">JD<button><Camera size={13}/></button></div></div><div className="stack"><Field label="Full Name" value="John Doe"/><Field label="Email Address" value="john.doe@gmail.com"/><Field label="Phone Number" value="+234 801 234 5678"/><Field label="Date of Birth" value="12 March 1995"/><Button className="wide">Save Changes</Button></div></MemberShell>
}

function MyRegistrations() {
  return <MemberShell active="events" title="My Registrations" backTo="/events"><div className="ticket-card"><div><b>Youth Conference 2024</b><small>25 May 2024 • 10:00 AM</small></div><span className="status">Registered</span></div></MemberShell>
}

function SignIn() {
  return <div className="onboarding-page"><div className="onboarding-card"><Logo/><h1>Welcome back</h1><p className="sub">Sign in to your account</p><div className="stack"><Field label="Email Address" value="john.doe@gmail.com" icon={Mail}/><Field label="Password" value="••••••••••" type="password" icon={Lock}/><Button className="wide">Sign In</Button><Link className="center link-button" to="/home">Continue as demo member</Link></div></div></div>
}

export default function App() {
  return <Routes>
    <Route path="/" element={<Welcome/>}/>
    <Route path="/signin" element={<SignIn/>}/>
    <Route path="/onboarding/create-account" element={<CreateAccount/>}/>
    <Route path="/onboarding/verify" element={<Verify/>}/>
    <Route path="/onboarding/profile" element={<CompleteProfile/>}/>
    <Route path="/onboarding/ministries" element={<SelectMinistries/>}/>
    <Route path="/onboarding/notifications" element={<NotificationPreferences/>}/>
    <Route path="/onboarding/complete" element={<OnboardingComplete/>}/>
    <Route path="/home" element={<HomePage/>}/>
    <Route path="/announcements/1" element={<Announcements/>}/>
    <Route path="/events" element={<EventsPage/>}/>
    <Route path="/events/:id" element={<EventDetails/>}/>
    <Route path="/events/:id/register" element={<EventRegistration/>}/>
    <Route path="/events/youth-conference-2024/success" element={<RegistrationSuccess/>}/>
    <Route path="/my-registrations" element={<MyRegistrations/>}/>
    <Route path="/forms" element={<FormsPage/>}/>
    <Route path="/forms/prayer-request" element={<PrayerRequest/>}/>
    <Route path="/ministries" element={<MinistriesPage/>}/>
    <Route path="/ministries/:id" element={<MinistryDetails/>}/>
    <Route path="/notifications" element={<Notifications/>}/>
    <Route path="/notifications/1" element={<NotificationDetail/>}/>
    <Route path="/profile" element={<Profile/>}/>
    <Route path="/profile/edit" element={<EditProfile/>}/>
    <Route path="*" element={<Navigate to="/"/>}/>
  </Routes>
}
